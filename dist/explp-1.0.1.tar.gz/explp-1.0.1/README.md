# explp

Generating Explanations of Optimisation Solutions:
In the Context of Linear Programming

(First Version Available)

Last Updated: 
11th August 2018

By:       Zeyang Zhang

Contact:  zeyang.zhang.17@ucl.ac.uk (University Email)
          zeyang.zhang@qq.com (Personal Email)

For:      Master Dissertation Project for University College London (UCL)
          Master of Science Degree in Business Analytics (with specialisation in Computer Science)

With:     Satalia (NPComplete Ltd.)


Special Thanks to Dr. Daniel Hulme (UCL Computer Science and Satalia) and Dr. Christina Burt (Satalia)
